<?php
echo "asd";

	include("../inc/conn.php");
	include("../inc/functions.php");
	$localize = getLang("ajax");


	
	$result = mysqli_query($connection, $_POST['query']);

	echo json_encode($result);

?>
