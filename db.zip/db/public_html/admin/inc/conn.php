<?php
 error_reporting(0);
	session_start();
	$db_host = "dbmysql";
	$db_user = "root";
	$db_pass = "1234";
	$db_name = "db_election";
	$connection = mysqli_connect($db_host,$db_user,$db_pass,$db_name);
	if(!$connection){
		echo "FATAL ERROR!";
		exit();
	}
?>
