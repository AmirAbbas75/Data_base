<?php

namespace App\Http\Controllers;

use Illuminate\Routing\ResponseFactory;
use Illuminate\Http\Request;


use Illuminate\Support\Facades\Artisan;
use Symfony\Component\HttpKernel\Exception\HttpException;


class DBController extends Controller
{

    public function install(Request $request)
    {

        //Artisan::call('make:migration', [ 'name' => 'create_users_table']);
        //Artisan::call('make:migration', ['name' => 'create_election_table']);
        
          Artisan::call('migrate', [ "--force" => true]);

        return response()->json(['status' => 'done']);
    }

   public function query(Request $request)
    {

       	//error_reporting(0);
	//session_start();
	$db_host = "dbmysql";
	$db_user = "root";
	$db_pass = "1234";
	$db_name = "db_election";
	$connection = mysqli_connect($db_host,$db_user,$db_pass,$db_name);
	if(!$connection){
		echo "FATAL ERROR!";
		exit();
	}
	
	$result = mysqli_query($connection, $request->post('query'));

	//echo json_encode($result);

                $new_array = [];
		while( $row = mysqli_fetch_array( $result)){
 		   $new_array[] = $row; // Inside while loop
		}

        return response()->json($new_array, 200);
    }


}
