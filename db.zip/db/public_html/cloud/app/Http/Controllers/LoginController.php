<?php

namespace App\Http\Controllers;

use Illuminate\Routing\ResponseFactory;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

use Symfony\Component\HttpKernel\Exception\HttpException;
use App\Helpers\PersianCalendar;
use App\Helpers\JWT;
use App\JWT\ReallySimpleJWT\Token;

class LoginController extends Controller
{
    public function login(Request $request)
    {
     
             
         $email = $request->json('email');
         $pass = $request->json('pass');
         $pass = md5($pass);
         
         
         $user = DB::table('users')
                     ->where('content->email', $email)
                     //->where('content->pass', $pass)
                     ->first();

        $id = -1;
        if($user){
            $id = $user->id;
            $content = json_decode($user->content, true);
            if($content['pass'] == $pass){
                
            }else {
                return response()->json(['status' => 'error'],403);
            }
        }else {
            $id = DB::table('users')
                ->insertGetId(['content' => json_encode([
                    'email'=>$email,
                    'pass'=> $pass,
                     'date'=>persianCalendar::now(),
                     'ip' =>$request->ip()
                    ],JSON_UNESCAPED_UNICODE | JSON_FORCE_OBJECT |JSON_UNESCAPED_LINE_TERMINATORS | JSON_PARTIAL_OUTPUT_ON_ERROR | JSON_UNESCAPED_SLASHES)]);
        }
    
         $token = JWT::getToken(['id'=>$id]);

         return response()->json(['status' => 'done', 'token' => $token, 'id' => $id]);
     
    }

}
